import torch


class AdamN(torch.optim.Optimizer):
    """
    AdamN optimizer with nested momentum and exact bias correction.

    Update:
        v_t = beta1 * v_{t-1} + (1 - beta1) * g_t
        a_t = beta2 * a_{t-1} + (1 - beta2) * v_t
        s_t = beta3 * s_{t-1} + (1 - beta3) * g_t^2

        theta_t = theta_{t-1} - lr * a_hat_t / (sqrt(s_hat_t) + eps)

    Notes:
        - Uses an FP32 master parameter copy for numerical stability.
        - Optimizer states v_t, a_t, and s_t are stored in FP32.
        - Recommended for AMP, bf16, and fp16 training.
    """

    def __init__(
        self,
        params,
        lr=1e-3,
        betas=(0.9, 0.1, 0.999),
        eps=1e-8,
        weight_decay=0.0,
        decoupled_wd=True,
        bias_correction="exact",
    ):
        if lr < 0.0:
            raise ValueError(f"Invalid lr: {lr}")

        if eps < 0.0:
            raise ValueError(f"Invalid eps: {eps}")

        if len(betas) != 3:
            raise ValueError("betas must be a tuple of three values: (beta1, beta2, beta3)")

        b1, b2, b3 = betas

        for nm, b in zip(("beta1", "beta2", "beta3"), (b1, b2, b3)):
            if not (0.0 <= b < 1.0):
                raise ValueError(f"Invalid {nm}: {b}")

        if bias_correction not in ("exact", "simple"):
            raise ValueError("bias_correction must be 'exact' or 'simple'")

        defaults = dict(
            lr=lr,
            betas=betas,
            eps=eps,
            weight_decay=weight_decay,
            decoupled_wd=decoupled_wd,
            bias_correction=bias_correction,
        )

        super().__init__(params, defaults)

    @staticmethod
    def _f_exact(t, b1, b2):
        if t <= 0:
            return 0.0

        if abs(b2 - b1) < 1e-12:
            beta = b1
            return (1.0 - beta ** t) - (1.0 - beta) * t * (beta ** t)

        b1_pow_t = b1 ** t
        b2_pow_t = b2 ** t

        term1 = 1.0 - b2_pow_t
        term2 = (1.0 - b2) * b1 * (b2_pow_t - b1_pow_t) / (b2 - b1)

        return term1 - term2

    @torch.no_grad()
    def step(self, closure=None):
        loss = None

        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            lr = group["lr"]
            b1, b2, b3 = group["betas"]
            eps = group["eps"]
            wd = group["weight_decay"]
            decoupled = group["decoupled_wd"]
            bc_mode = group["bias_correction"]

            for p in group["params"]:
                if p.grad is None:
                    continue

                if p.grad.is_sparse:
                    raise RuntimeError("AdamN does not support sparse gradients")

                grad32 = p.grad.detach().to(torch.float32)
                state = self.state[p]

                if len(state) == 0:
                    state["step"] = 0
                    state["param_fp32"] = p.detach().to(torch.float32).clone()
                    state["v_t"] = torch.zeros_like(state["param_fp32"])
                    state["a_t"] = torch.zeros_like(state["param_fp32"])
                    state["s_t"] = torch.zeros_like(state["param_fp32"])

                param_fp32 = state["param_fp32"]
                v_t = state["v_t"]
                a_t = state["a_t"]
                s_t = state["s_t"]

                state["step"] += 1
                t = state["step"]

                if wd != 0.0:
                    if decoupled:
                        param_fp32.mul_(1.0 - lr * wd)
                    else:
                        grad32 = grad32.add(param_fp32, alpha=wd)

                v_t.mul_(b1).add_(grad32, alpha=1.0 - b1)
                a_t.mul_(b2).add_(v_t, alpha=1.0 - b2)
                s_t.mul_(b3).addcmul_(grad32, grad32, value=1.0 - b3)

                if bc_mode == "exact":
                    f_t = max(AdamN._f_exact(t, b1, b2), 1e-16)
                    a_hat = a_t / f_t
                else:
                    a_hat = a_t / max(1.0 - (b2 ** t), 1e-16)

                s_hat = s_t / max(1.0 - (b3 ** t), 1e-16)

                denom = s_hat.sqrt().add_(eps)
                param_fp32.addcdiv_(a_hat, denom, value=-lr)

                p.copy_(param_fp32.to(dtype=p.dtype))

        return loss
